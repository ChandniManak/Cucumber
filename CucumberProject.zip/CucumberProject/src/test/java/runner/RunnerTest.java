package runner;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(
		plugin = { 
				"pretty", 
				"html:target/cucumber-reports/", 
				"json:target/Cucumber/Cucumber.json",
				"junit:target/Cucumber/Cucumber.xml",
				//"com.cucumber.listener.ExtentCucumberFormatter:target/cucumber-reports/report.html" 
				}, 
		monochrome = true, 
		glue = {"stepDefinition" }, 
		features = { "src/test/resources/features" }, 
		tags = ("@flight"))
public class RunnerTest {
	
	
	
}
