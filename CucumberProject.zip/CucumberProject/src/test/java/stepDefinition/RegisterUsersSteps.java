package stepDefinition;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import pageObjects.NewToursRegister;

public class RegisterUsersSteps {

	WebDriver driver = Hooks.driver;
	WebDriverWait wait = Hooks.wait;

	NewToursRegister newToursRegister = new NewToursRegister(driver);

	@Given("^User navigates to homepage of \"([^\"]*)\"$")
	public void user_navigates_to_homepage_of(String url) {
		driver.get(url);
	}

	@When("^User clicks on the register link$")
	public void user_clicks_on_the_register_link() {
		newToursRegister.clickRegisterLink();
	}

	@When("^Enters First name \"([^\"]*)\"$")
	public void enters_First_name(String firstName) {
		newToursRegister.enterFirstName(firstName);
	}

	@When("^Enters Last Name \"([^\"]*)\"$")
	public void enters_Last_Name(String lastName) {
		newToursRegister.enterLastName(lastName);
	}
	@When("^Enters Phone \"([^\"]*)\"$")
	public void enters_Phone(String phone) {
		newToursRegister.enterPhone(phone);
	}
	
	@When("^Enters Email \"([^\"]*)\"$")
	public void enters_Email(String email) {
		newToursRegister.enterEmail(email);
	}

	@When("^Enters address \"([^\"]*)\"$")
	public void enters_address(String address) {
		newToursRegister.enterAddress(address);
	}

	@When("^Enters city \"([^\"]*)\"$")
	public void enters_city(String city) {
		newToursRegister.enterCity(city);
	}

	@When("^Enters State \"([^\"]*)\"$")
	public void enters_State(String state) {
		newToursRegister.enterState(state);
	}

	@When("^Enters Postal Code \"([^\"]*)\"$")
	public void enters_Postal_Code(String postalCode) {
		newToursRegister.enterPostalCode(postalCode);
	}

	@When("^Selects Country \"([^\"]*)\"$")
	public void selects_Country(String country) {
		newToursRegister.selectCountryByValue(country.toUpperCase());
	}

	@When("^Enters Username of your choice \"([^\"]*)\"$")
	public void enters_Username_of_your_choice(String username) {
		newToursRegister.enterUserName(username);
	}

	@When("^Enters password \"([^\"]*)\"$")
	public void enters_password(String password) {
		newToursRegister.enterPassword(password);
	}

	@When("^Enters same password in confirm password field \"([^\"]*)\"$")
	public void enters_same_password_in_confirm_password_field(String password) {
		newToursRegister.enterConfirmPassword(password);
	}

	@Then("^User should be able to submit the form$")
	public void user_should_be_able_to_submit_the_form()  {
		newToursRegister.submit();
	}
}
